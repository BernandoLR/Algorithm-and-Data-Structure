/*
	Program Name : Stack
	Created by Bernando Lumban Raja
	1 sept 2016
*/
#ifndef _Stack_H
#define _Stack_H

typedef int ElementType;

struct Node;
typedef struct Node *PtrToNode;
typedef PtrToNode Stack;

Stack CreateStack(void);
Stack Push(ElementType X, Stack S);
void Pop(Stack S);
ElementType Retrieve(Stack S);
int IsEmpty(Stack S);
ElementType Top(Stack S);
void MakeEmpty(Stack S);


#endif
