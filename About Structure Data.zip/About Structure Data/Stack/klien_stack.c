/*
	Program Name : Stack
	Created by Bernando Lumban Raja
	1 sept 2016
*/
#include<stdio.h>
#include<stdlib.h>
#include "Stack.h"

void PrintStack(const Stack S);
void PrintStack(const Stack S)
{
	while(!IsEmpty(S))
	{
		printf("%d ",Retrieve(S));
	}
	printf("\n");
}

int main()
{
	Stack S = NULL;
	S = CreateStack();
	int i;
	for(i=0;i<8;i++)
	{
	Push(i,S);
	}
	printf("Top of stack is %d\n",Top(S));
		
	
}

