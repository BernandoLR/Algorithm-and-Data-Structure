/*
	Program Name : Stack
	Created by Bernando Lumban Raja
	1 sept 2016
*/
#include<stdio.h>
#include<stdlib.h>
#include "Stack.h"

struct Node{
	ElementType Element;
	Stack Next;
};

Stack CreateStack(void)
{
	Stack S;
	S = malloc(sizeof(struct Node));
	if(S == NULL)
		printf("Unallocated memory\n");
	S->Next = NULL;
	return S;
}

Stack Push(ElementType X, Stack S)
{
	PtrToNode temp;
	temp = malloc(sizeof(struct Node));
	if(temp == NULL)
		printf("Unallocated memory\n");
	temp->Element = X;
	temp->Next = S->Next;
	S->Next = temp;
}

void Pop(Stack S)
{
	PtrToNode tempcell = NULL;
	if(!IsEmpty(S))
	{
		S->Next = tempcell;
		tempcell->Next = S->Next;
		free(tempcell);
	}
}

ElementType Retrieve(Stack S)
{
	return S->Element;
}

int IsEmpty(Stack S)
{
	return S->Next == NULL;
}

ElementType Top(Stack S)
{
	if(!IsEmpty(S))
		return S->Next->Element;
	else
		return 0;
}

Stack Advance(Stack S)
{
	return S->Next;
}

void MakeEmpty(Stack S)
{
	if(S == NULL)
		printf("Empty stack\n");
	else
	{
		while(!IsEmpty(S))
			Pop(S);
	}		
	
}
