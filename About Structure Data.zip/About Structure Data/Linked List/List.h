/*
	Program Name : Linked List
	Created by Bernando Lumban Raja
	16 september 2016
*/

#ifndef List_H
#define List_H

typedef int ElementType;

struct Node;
typedef struct Node *PtrToNode;
typedef PtrToNode Position;
typedef PtrToNode List;

List ConstructList(List L);
Position Header(List L);
ElementType Retrieve(Position P);
Position Advance(Position P);
int Islast(Position P,List L);
int IsEmpty(List L);
ElementType Update(ElementType X,Position P);
Position Find(ElementType X, List L);
Position FindPrevious(ElementType X, List L);
void Insert(ElementType X, List L, Position P);
void Delete(ElementType X, List L);
void Delete_list(List L);


#endif
