/*
	Program Name : Linked List
	Created by Bernando Lumban Raja
	16 september 2016
*/
#include<stdio.h>
#include<stdlib.h>
#include "List.h"

struct Node{
	ElementType Element;
	Position Next;
};

List ConstructList(List L)
{
	L = malloc(sizeof(struct Node));
	if(L == NULL)
		printf("Unallocated memory\n");
	L->Next = NULL;
	return L;
}

Position Header(List L)
{
	return L;
}

ElementType Retrieve(Position P)
{
	return P->Element;
}

Position Advance(Position P)
{
	return P->Next;
}

int IsLast(Position P, List L)
{
	return P->Next == NULL;
}

int IsEmpty(List L)
{
	return L->Next == NULL;
}

ElementType Update(ElementType X,Position P)
{
	P->Element = X;
}

Position Find(ElementType X, List L)
{
	Position P = NULL;
	P = L->Next;
	while(P != NULL && P->Element != X)
		P = Advance(P);
	return P;
}

Position FindPrevious(ElementType X, List L)
{
	Position P = NULL;
	P = L;
	while(P->Next != NULL && P->Next->Element != X)
		P = Advance(P);
	return P;
}

void Insert(ElementType X, List L, Position P)
{
	Position tempcell = NULL;
	tempcell = malloc(sizeof(struct Node));
	if(tempcell == NULL)
		printf("Unallocated memory\n");
	tempcell->Element = X;
	tempcell->Next = P->Next;
	P->Next = tempcell;
}

void Delete(ElementType X, List L)
{
	Position P,temp;
	P = FindPrevious(X,L);
	if(!IsLast(P,L))
	{
		temp = P->Next;
		P->Next = temp->Next;
		free(temp);
	}
}

void Delete_list(List L)
{
	Position P;
	P = L->Next;
	while(P != NULL)
	{
		free(P);
		P = Advance(P);
	}
}
