/*
	Program Name : Linked List
	Created by Bernando Lumban Raja
	16 september 2016
*/
#include<stdio.h>
#include<stdlib.h>
#include "List.h"

void PrintList(const List L);
void PrintList(const List L)
{
	Position P = Header(L);
	printf("List Element is ");
	while(!IsLast(P,L))
	{
		P = Advance(P);
		printf("%d ",Retrieve(P));
	}
	printf("\n");
}

int main(int argc, char *argv[])
{
	List L = NULL;
	Position P = NULL;
	
	L = ConstructList(L);
	P = Header(L);
	
	Insert(1,L,P);
	P = Advance(P);
	PrintList(L);
	
	Insert(2,L,P);
	P = Advance(P);
	PrintList(L);
	
	Insert(3,L,P);
	P = Advance(P);
	PrintList(L);
	
	Insert(4,L,P);
	P = Advance(P);
	PrintList(L);
	
	Delete(2,L);
	P = Advance(P);
	PrintList(L);
	
	if((P = Find(3,L)) != NULL)
	{
		printf("Element %d found\n\n",Retrieve(P));
	}
	
	if((P = FindPrevious(3,L)) != NULL)
	{
		printf("Element previously found\n");
		printf("its element is %d\n\n",Retrieve(P));
	}
	
	if((P = Find(4,L)) != NULL)
	{
		Update(7,P);
		printf("The element has been updated\n\n");
		PrintList(L);
	}
}
