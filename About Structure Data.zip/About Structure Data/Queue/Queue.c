/*
	Program Name : Queue
	Created by Bernando Lumban Raja
	1 sept 2016
*/
#include<stdio.h>
#include<stdlib.h>
#include "Queue.h"

struct Node
{
	ElementType Element;
	Queue Next;
};

Queue CreateQueue(void)
{
	Queue Q;
	Q = malloc(sizeof(struct Node));
	if(Q == NULL)
		printf("Unallocated memory\n");
	Q->Next = NULL;
	return Q;
}

Position Header(Queue Q)
{
	return Q;
}

void EnQueue(ElementType X, Queue Q,Position P)
{
	Position temp = NULL;
	temp = malloc(sizeof(struct Node));
	if(temp == NULL)
		printf("Unallocated memory\n");
	else{
	temp->Element = X;
	temp->Next = P->Next;
	P->Next = temp;
	}
}

int IsEmpty(Queue Q)
{
	return Q->Next == NULL;
}

Position Advance(Position P)
{
	return P->Next;
}

ElementType Retrieve(Position P)
{
	return P->Element;
}

int IsLast(Position P, Queue Q)
{
	return P->Next == NULL;
}

void DeQueue(Queue Q)
{
	Position temp = NULL;
	if(!IsEmpty(Q)){
	temp = Q->Next;
	Q->Next = temp->Next;
	free(temp);
	}
}

void MakeEmpty(Queue Q)
{
	if(Q == NULL)
		printf("Empty Queue\n");
	else
	{
		while(!IsEmpty(Q))
			DeQueue(Q);
	}
}
void DisposeQueue(Queue Q)
{
	MakeEmpty(Q);
	free(Q);
}
