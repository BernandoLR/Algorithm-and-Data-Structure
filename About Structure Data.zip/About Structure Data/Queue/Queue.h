/*
	Program Name : Queue
	Created by Bernando Lumban Raja
	1 sept 2016
*/
#ifndef _Queue_H
#define _Queue_H

typedef int ElementType;
struct Node;
typedef struct Node *PtrToNode;
typedef PtrToNode Queue;
typedef PtrToNode Position;

Queue CreateQueue(void);
Position Header(Queue Q);
void EnQueue(ElementType X, Queue Q,Position P);
void DeQueue(Queue Q);
int IsEmpty(Queue Q);
int IsLast(Position P, Queue Q);
Position Advance(Position P);
ElementType Retrieve(Position P);
void MakeEmpty(Queue Q);
void DisposeQueue(Queue Q);


#endif
