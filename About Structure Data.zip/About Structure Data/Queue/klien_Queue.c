/*
	Program Name : Queue
	Created by Bernando Lumban Raja
	1 sept 2016
*/
#include<stdio.h>
#include "Queue.h"

void PrintQueue(const Queue Q);
void PrintQueue(const Queue Q)
{
	Position P = Header(Q);
	printf("Elemets of Queue is ");
	while(!IsLast(P,Q))
	{
		P = Advance(P);
		printf("%d ",Retrieve(P));
	}
	printf("\n");
}

int main(int argc, char *argv[])
{
	Queue Q = NULL;
	Position P = NULL;
	
	Q = CreateQueue();
	P = Header(Q);
	
	EnQueue(77,Q,P);	//Insert Node Queue
	P = Advance(P);		//Print Queue
	PrintQueue(Q);
	
	EnQueue(88,Q,P);	//Insert Node Queue
	P = Advance(P);		//Print Queue
	PrintQueue(Q);
	
	EnQueue(8,Q,P);		//Insert Node Queue
	P = Advance(P);		//Print Queue
	PrintQueue(Q);
	
	DeQueue(Q);			//Delete Queue
	PrintQueue(Q);		//Print Queue
}
